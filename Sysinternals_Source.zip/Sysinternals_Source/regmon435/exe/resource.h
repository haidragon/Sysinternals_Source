//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by regmon.RC
//
#define IDRESET                         3
#define IDC_DONE                        3
#define IDM_EXIT                        104
#define IDM_SAMPLE                      105
#define IDM_ABOUT                       300
#define IDB_TOOLBAR                     400
#define ID_LIST                         1000
#define IDC_PROCFILTER                  1000
#define IDC_PATHFILTER                  1001
#define IDC_EXCLUDEFILTER               1002
#define IDC_HISTORY                     1003
#define IDC_FILTERSTRING                1003
#define IDC_PROCEXCLUDE                 1004
#define IDC_EXFILTERSTRING              1004
#define IDC_HIFILTERSTRING              1005
#define IDC_SUCCESS                     1006
#define IDC_ERROR                       1007
#define IDC_LOGREADS                    1008
#define IDC_LOGWRITES                   1009
#define IDC_LINK                        1009
#define IDC_SPIN                        1022
#define IDC_SAMPLE                      1023
#define IDC_RADIOFG                     1028
#define IDC_RADIOBG                     1029
#define IDC_READ                        1031
#define IDC_WRITE                       1032
#define IDC_LOGAUX                      1033
#define IDC_DRIVE                       1050
#define IDM_SAVE                        40007
#define IDM_SAVEAS                      40012
#define IDM_ZEROSTATS                   40016
#define IDM_HELP                        40017
#define IDM_CAPTURE                     40018
#define IDM_AUTOSCROLL                  40019
#define IDM_CLEAR                       40020
#define IDM_FILTER                      40022
#define IDM_FIND                        40024
#define IDM_BOOTLOG                     40026
#define IDM_HISTORY                     40027
#define IDM_JUMP                        40028
#define IDM_TIME                        40029
#define IDM_STAYTOP                     40030
#define IDM_FONT                        40032
#define IDM_SHOWMS                      40033
#define IDM_DELETE                      40034
#define IDM_FINDPREV                    40035
#define IDM_FINDAGAIN                   40038
#define IDM_COPY                        40039
#define IDM_HIGHLIGHT                   40044
#define IDM_ONTOP                       40045
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        124
#define _APS_NEXT_COMMAND_VALUE         40036
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
