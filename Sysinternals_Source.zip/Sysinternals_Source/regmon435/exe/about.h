

BOOL CALLBACK AboutDlgProc( HWND hDlg, UINT message, UINT wParam, LONG lParam );