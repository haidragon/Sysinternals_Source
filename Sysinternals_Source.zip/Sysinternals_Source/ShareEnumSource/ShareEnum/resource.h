//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ShareEnum.rc
//
#define IDS_CHANGE                      33
#define IDS_READ                        34
#define IDS_FULL_CONTROL                35
#define IDB_BITMAP2                     124
#define IDI_FILEBAD                     323
#define IDI_UPARROW                     330
#define IDI_DOWNARROW                   331
#define IDI_FILE                        332
#define IDI_FILEGOOD                    333
#define IDC_REFRESH                     1081
#define IDC_LIST                        1090
#define IDC_EXPORT                      1091
#define IDC_LINK                        1092
#define IDC_DOMAIN                      1094
#define IDC_DESCRIPTION                 1095
#define IDC_STATUS                      1098
#define IDC_FIRST                       1100
#define IDC_LAST                        1101
#define IDC_ABOUT                       40001
#define IDC_COMPARE                     40030
#define IDC_PROPERTIES                  40031
#define IDC_EXPLORE                     40032
#define IDC_MAXTHREADS                  40033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40034
#define _APS_NEXT_CONTROL_VALUE         1101
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
